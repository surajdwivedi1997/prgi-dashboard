package com.example.prgi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrgiDashboardApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrgiDashboardApplication.class, args);
    }

}
